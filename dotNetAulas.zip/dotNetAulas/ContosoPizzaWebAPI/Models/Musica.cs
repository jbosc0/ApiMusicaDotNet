namespace MusicaWebAPI.Models;

public class Musica
{
  public int Id { get; set; }
  public string? Nome { get; set; }
  public string Interpretador { get; set; }
  public string Genero { get; set;}
  public double Duracao { get; set;}
}
