using Microsoft.AspNetCore.Mvc;
using MusicaWebAPI.Models;
using MusicaWebAPI.Services;

namespace MusicaWebAPI.Controllers;

[ApiController]
[Route("api/musica")]
public class MusicaController : ControllerBase
{
  // Obter todas as musicas
  [HttpGet]
  public ActionResult<List<Musica>> GetAll() => MusicaService.GetAll();

  // Recuperar apenas uma música
  [HttpGet("{id}")]
  public ActionResult<Musica> Get(int id)
  {
    var musica = MusicaService.Get(id);
    if (musica == null) return NotFound();
    return musica;
  }

  // Adicionar uma música
  [HttpPost]
  public IActionResult Create(Musica musica)
  {
    MusicaService.Add(musica);
    return CreatedAtAction(nameof(Get), new { id = musica.Id }, musica);
  }

  // Remover uma música
  [HttpDelete("{id}")]
  public IActionResult Delete(int id)
  {
    var musica = MusicaService.Get(id);
    if (musica is null) return NotFound();
    MusicaService.Delete(id); 
    return NoContent();
  }

  // Modificar uma música
  [HttpPut("{id}")]
  public IActionResult Update(int id, Musica musica)
  {
    if (id != musica.Id) return BadRequest();
    var existingMusica = MusicaService.Get(id);
    if (existingMusica is null) return NotFound();
    MusicaService.Update(musica);
    return NoContent();
  }
}
