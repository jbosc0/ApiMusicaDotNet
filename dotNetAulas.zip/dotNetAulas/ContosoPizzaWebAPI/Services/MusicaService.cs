using MusicaWebAPI.Models;

namespace MusicaWebAPI.Services;

public class MusicaService
{
  //Atributos Privados
  private static List<Musica> Musicas { get; }
  private static int nextId = 3;

  //Construtor
  static MusicaService()
  {
    Musicas = new List<Musica>
        {
            new Musica { Id = 1, Nome = "Avesso", Interpretador = "Jorge Vercillo", Genero = "MPB", Duracao = 303 },
            new Musica { Id = 2, Nome = "Miséria no Japão", Interpretador="Ney Matogrosso", Genero="Rock", Duracao=192 },
            new Musica  {Id = 3, Nome = "Everything I Wanted", Interpretador = "Billie Eilish", Genero= "Pop", Duracao= 243 }

        };
  }

  //Métodos públicos
  public static List<Musica> GetAll() => Musicas;

  public static Musica? Get(int id) => Musicas.FirstOrDefault(p => p.Id == id);

  public static void Add(Musica musica)
  {
    musica.Id = nextId++;
    Musicas.Add(musica);
  }

  public static void Delete(int id)
  {
    var musica = Get(id);
    if (musica is null)
      return;

    Musicas.Remove(musica);
  }

  public static void Update(Musica musica)
  {
    var index = Musicas.FindIndex(p => p.Id == musica.Id);
    if (index == -1)
      return;

    Musicas[index] = musica;
  }
}
